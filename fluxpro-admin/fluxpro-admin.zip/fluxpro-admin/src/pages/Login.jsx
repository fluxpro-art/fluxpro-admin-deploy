
function Login() {
  return (
    <div>
      <h2>Login</h2>
      <input placeholder="E-mail" />
      <input placeholder="Senha" type="password" />
      <button>Entrar</button>
    </div>
  );
}

export default Login;
