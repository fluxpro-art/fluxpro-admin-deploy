
import Header from '../components/Header';

function Settings() {
  return (
    <div>
      <Header />
      <h2>Configurações</h2>
      <p>Ajustes do sistema aqui.</p>
    </div>
  );
}

export default Settings;
